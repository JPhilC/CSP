﻿Clear Sky Prediction by Lunatic Software
Written by Phil Crompton, email phil@unitysoftware.co.uk

Requirements.
=============
You must have the .NET Framework 4.5 runtime installed. This comes as standard with Windows Vista onwards.

Instructions for use.
=====================
1. Unzip all files into a folder.
2. Create a short cut on your desktop to the ClearSkyPrediction.exe file
3. Edit the shortcut to add the Latitude and longitude in decimals as the first and second command parameter in the target.

	e.g. "C:\ClearSkyPrediction\ClearSkyPrediction.exe" 52.7 -1.4

